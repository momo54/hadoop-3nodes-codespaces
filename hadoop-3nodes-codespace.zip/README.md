# Hadoop 3-node cluster for GitHub Codespaces

This repo runs a minimal Hadoop cluster (1 master, 2 workers) in 3 Docker containers inside a Codespace.

## Usage

1. Open in Codespaces.
2. Wait until the build finishes (`docker compose up -d --build` is run automatically).
3. Check UIs (forwarded ports):
   - NameNode: `9870`
   - YARN RM: `8088`
   - MR History: `19888`

## Run WordCount

```bash
docker exec -it hadoop-master bash -lc '
hdfs dfs -mkdir -p /input &&
echo "to be or not to be" > /tmp/text.txt &&
hdfs dfs -put -f /tmp/text.txt /input &&
hadoop jar $HADOOP_HOME/share/hadoop/mapreduce/hadoop-mapreduce-examples-*.jar wordcount /input /output &&
hdfs dfs -cat /output/part-r-00000
'
```

## Stop cluster

```bash
docker compose down -v
```
